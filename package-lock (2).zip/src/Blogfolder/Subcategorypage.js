import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Box, Typography, Paper, Avatar, Divider, IconButton
} from '@mui/material';
import ThumbUpIcon from '@mui/icons-material/ThumbUp';
import ThumbDownIcon from '@mui/icons-material/ThumbDown';
import ChatBubbleOutlineIcon from '@mui/icons-material/ChatBubbleOutline';
import avatarImage from './Images/avatar1.png';
import Navbar from './Navbar';

const SubcategoryPage = () => {
  const { subcategoryName } = useParams();
  const [blogs, setBlogs] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const res = await axios.get('http://localhost:5000/blogs');
        const posts = res.data;

        const filtered = posts.filter(
          post => post.subcategory.toLowerCase() === subcategoryName.toLowerCase()
        );

        const blogsWithStats = await Promise.all(
          filtered.map(async (post) => {
            try {
              const [commentRes, likeRes, unlikeRes] = await Promise.all([
                axios.get(`http://localhost:5000/comment-count/${post.id}`),
                axios.get(`http://localhost:5000/like/${post.id}`),
                axios.get(`http://localhost:5000/unlike/${post.id}`)
              ]);
              return {
                ...post,
                comments: Number(commentRes.data.commentCount) || 0,
                likes: Number(likeRes.data.likeCount) || 0,
                unlikes: Number(unlikeRes.data.unlikeCount) || 0
              };
            } catch {
              return { ...post, comments: 0, likes: 0, unlikes: 0 };
            }
          })
        );

        setBlogs(blogsWithStats);
      } catch (err) {
        console.error('Error loading subcategory blogs:', err);
      }
    };

    fetchBlogs();
  }, [subcategoryName]);

  const handleLike = async (postId) => {
    try {
      await axios.post('http://localhost:5000/like', { post_id: postId });
      const res = await axios.get(`http://localhost:5000/like/${postId}`);
      setBlogs(prev =>
        prev.map(post =>
          post.id === postId ? { ...post, likes: Number(res.data.likeCount) || 0 } : post
        )
      );
    } catch (err) {
      console.error('Like failed', err);
    }
  };

  const handleUnlike = async (postId) => {
    try {
      await axios.post('http://localhost:5000/unlike', { post_id: postId });
      const res = await axios.get(`http://localhost:5000/unlike/${postId}`);
      setBlogs(prev =>
        prev.map(post =>
          post.id === postId ? { ...post, unlikes: Number(res.data.unlikeCount) || 0 } : post
        )
      );
    } catch (err) {
      console.error('Unlike failed', err);
    }
  };

  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    return `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}`;
  };

  return (
    <>
    <Navbar />
    <Box p={3} sx={{ backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
      <Typography variant="h5" fontWeight="bold" mb={3}>
        Posts in Subcategory: {subcategoryName}
      </Typography>

      {blogs.length === 0 ? (
        <Typography>No posts available in this subcategory.</Typography>
      ) : (
        blogs.map((post, index) => (
          <React.Fragment key={post.id}>
            <Paper sx={{ p: 3, mb: 3 }}>
              <Box sx={{ display: 'flex', gap: 3, flexDirection: { xs: 'column', sm: 'row' } }}>
                {/* Left: Avatar + Date */}
                <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                  <Avatar src={avatarImage} sx={{ width: 56, height: 56 }} />
                  <Typography variant="caption" color="text.secondary" mt={1}>
                    {formatDate(post.published_date)}
                  </Typography>
                </Box>

                

                {/* Center: Post Details */}
                <Box sx={{ flex: 1 }}>
                  <Typography variant="h6" fontWeight="bold" gutterBottom>
                    {post.title}
                  </Typography>

                  <Typography variant="subtitle2" color="text.secondary">
                    Category: <strong>{post.category}</strong> | Subcategory: <strong>{post.subcategory}</strong>
                  </Typography>

                    {/* Like/Unlike/Comments */}
                  <Box sx={{ display: 'flex', alignItems: 'center', justifyContent:'flex-end', gap: 1.5, mt: 2 }}>
                    <IconButton onClick={() => handleLike(post.id)} size="small">
                      <ThumbUpIcon sx={{ color: '#4caf50' }} />
                    </IconButton>
                    <Typography variant="caption">{post.likes}</Typography>

                    <IconButton onClick={() => handleUnlike(post.id)} size="small">
                      <ThumbDownIcon sx={{ color: '#f44336' }} />
                    </IconButton>
                    <Typography variant="caption">{post.unlikes}</Typography>

                    <IconButton size="small">
                      <ChatBubbleOutlineIcon sx={{ color: '#ff9800' }} />
                    </IconButton>
                    <Typography variant="caption">{post.comments}</Typography>
                  </Box>


                        {/* Right: Blog Image */}
                <Box sx={{ display:'flex', justifyContent:'center',alignItems:'center'}} >
                  <img
                    src={post.imageUrl}
                    alt={post.title}
                    onError={(e) => { e.target.src = '/fallback-image.png'; }}
                    style={{ width: 400, height: 220, objectFit: 'cover', borderRadius: 10 }}
                  />
                </Box>

            <Box
         sx={{
           mb: 4,
           maxWidth: 700, 
           width: '100%',
           px: 2, 
           lineHeight: 1.8,
           fontSize: '1.05rem',
           textAlign: 'justify',
           '& p': {
             marginBottom: '1.2rem',
           },
           '& h1, & h2, & h3': {
             fontWeight: 'bold',
             mt: 3,
             mb: 1.5,
           },
           '& ul': {
             pl: 3,
             mb: 2,
           },
           '& li': {
             mb: 1,
           },
         }}
         dangerouslySetInnerHTML={{ __html: post.content || '<p>No content available.</p>' }}
       />

                
                </Box>

          
              </Box>
            </Paper>

            {index < blogs.length - 1 && <Divider />}
          </React.Fragment>
        ))
      )}
    </Box>
    </>
  );
};

export default SubcategoryPage;
