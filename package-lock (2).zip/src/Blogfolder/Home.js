import React, { useState, useEffect } from 'react';
import {
  Box, Paper, Avatar, Typography, Divider,
  Dialog, DialogTitle, DialogContent, DialogActions, Button, TextField, Chip
} from '@mui/material';
import ThumbDownIcon from '@mui/icons-material/ThumbDown';
import ThumbUpIcon from '@mui/icons-material/ThumbUp';
import ChatBubbleOutlineIcon from '@mui/icons-material/ChatBubbleOutline';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';
import avatarImage from './Images/avatar1.png';
import Navbar from './Navbar';

const Home = () => {
  const [blogPosts, setBlogPosts] = useState([]);
  const [subcategories, setSubcategories] = useState([]);
  const [openCommentDialog, setOpenCommentDialog] = useState(false);
  const [selectedPostId, setSelectedPostId] = useState(null);
  const [comment, setComment] = useState('');
  const { categoryName } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const res = await axios.get('http://localhost:5000/blogs');
        const posts = res.data;

const filteredPosts = categoryName
  ? posts.filter(post =>
      post.category.toLowerCase() === categoryName.toLowerCase() &&
      post.subcategory == "null"
    )
  : posts;



        const postsWithStats = await Promise.all(
          filteredPosts.map(async (post) => {
            try {
              const [commentRes, likeRes, unlikeRes] = await Promise.all([
                axios.get(`http://localhost:5000/comment-count/${post.id}`),
                axios.get(`http://localhost:5000/like/${post.id}`),
                axios.get(`http://localhost:5000/unlike/${post.id}`)
              ]);

              return {
                ...post,
                comments: Number(commentRes.data?.commentCount) || 0,
                likes: Number(likeRes.data.likeCount) || 0,
                unlikes: Number(unlikeRes.data.unlikeCount) || 0
              };
            } catch (err) {
              return { ...post, comments: 0, likes: 0, unlikes: 0 };
            }
          })
        );

        setBlogPosts(postsWithStats);

        // Fetch subcategories based on categoryName
        const subRes = await axios.get('http://localhost:5000/subcategories');
        const subList = subRes.data;

        const filteredSubs = categoryName
          ? subList.filter(sub => sub.categoryName.toLowerCase() === categoryName.toLowerCase())
          : [];

        setSubcategories(filteredSubs);
      } catch (err) {
        console.error('Error fetching blogs or subcategories:', err);
      }
    };

    fetchBlogs();
  }, [categoryName]);

  const handleOpenComments = (postId) => {
    setSelectedPostId(postId);
    setComment('');
    setOpenCommentDialog(true);
  };

  const handleCloseComments = () => {
    setOpenCommentDialog(false);
    setSelectedPostId(null);
    setComment('');
  };

  const handleSubmitComment = async () => {
    if (!comment.trim()) return alert('Comment cannot be empty');
    try {
      await axios.post('http://localhost:5000/api/comment', {
        post_id: selectedPostId,
        comment
      });
      const res = await axios.get(`http://localhost:5000/comments/${selectedPostId}`);
      setBlogPosts((prev) =>
        prev.map((post) =>
          post.id === selectedPostId
            ? { ...post, comments: Number(res.data.commentCount) || 0 }
            : post
        )
      );
      handleCloseComments();
    } catch (err) {
      console.error('Failed to submit comment:', err);
      alert('Failed to submit comment');
    }
  };

  const handleLike = async (postId) => {
    try {
      await axios.post('http://localhost:5000/like', { post_id: postId });
      const res = await axios.get(`http://localhost:5000/like/${postId}`);
      setBlogPosts((prev) =>
        prev.map((post) =>
          post.id === postId ? { ...post, likes: Number(res.data.likeCount) || 0 } : post
        )
      );
    } catch (err) {
      console.error('Like error:', err);
    }
  };

  const handleUnlike = async (postId) => {
    try {
      await axios.post('http://localhost:5000/unlike', { post_id: postId });
      const res = await axios.get(`http://localhost:5000/unlike/${postId}`);
      setBlogPosts((prev) =>
        prev.map((post) =>
          post.id === postId ? { ...post, unlikes: Number(res.data.unlikeCount) || 0 } : post
        )
      );
    } catch (err) {
      console.error('Unlike error:', err);
    }
  };

  const formatDate = (dateStr) => {
    const date = new Date(dateStr);
    return `${String(date.getDate()).padStart(2, '0')}/${String(date.getMonth() + 1).padStart(2, '0')}`;
  };

  return (
    <>
      <Navbar />
      <Box sx={{ display: 'flex', justifyContent: 'center', backgroundColor: '#cfd8dc' }}>
        <Box sx={{ width: 1100, p: 3 }}>
          <Typography variant="h5" fontWeight="bold" mb={2}>
            {categoryName ? `Posts in "${categoryName}"` : 'Latest Blog Posts'}
          </Typography>

      


          {/* Blog Posts */}
          {blogPosts.map((post, index) => (
            <React.Fragment key={post.id}>
              <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 3 }}>
                <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', width: 80 }}>
                  <Avatar alt="User Avatar" src={avatarImage} sx={{ width: 56, height: 56 }} />
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
                    {formatDate(post.published_date)}
                  </Typography>
                </Box>
                <Box sx={{ flex: 1, pl: 2 }}>
                  <Typography variant="h6" fontWeight="bold">{post.title}</Typography>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mt: 1 }}>
                    <Typography variant="caption" sx={{
                      backgroundColor: '#1976d2', color: '#fff',
                      px: 2, py: 0.5, borderRadius: 20, fontWeight: 'bold'
                    }}>
                      {post.category}
                    </Typography>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, cursor: 'pointer' }} onClick={() => handleLike(post.id)}>
                      <ThumbUpIcon sx={{ color: '#4caf50', fontSize: 18 }} />
                      <Typography variant="caption">{post.likes || 0}</Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, cursor: 'pointer' }} onClick={() => handleUnlike(post.id)}>
                      <ThumbDownIcon sx={{ color: '#e53935', fontSize: 18 }} />
                      <Typography variant="caption">{post.unlikes || 0}</Typography>
                    </Box>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, cursor: 'pointer' }} onClick={() => handleOpenComments(post.id)}>
                      <ChatBubbleOutlineIcon sx={{ color: '#ff9800', fontSize: 18 }} />
                      <Typography variant="caption">{post.comments || 0}</Typography>
                    </Box>
                  </Box>
                </Box>
                <Box sx={{ cursor: 'pointer' }} onClick={() => navigate(`/blog/${post.id}`)}>
                  <img
                    src={post.imageUrl}
                    alt={post.title}
                    style={{ width: 100, height: 100, objectFit: 'cover', borderRadius: 8 }}
                    onError={(e) => { e.target.src = '/fallback-image.png'; }}
                  />
                </Box>
              </Box>
              {index < blogPosts.length - 1 && <Divider />}
            </React.Fragment>
          ))}

          {/* Comment Dialog */}
          <Dialog open={openCommentDialog} onClose={handleCloseComments} maxWidth="sm" fullWidth>
            <DialogTitle>Leave a Comment</DialogTitle>
            <DialogContent>
              <TextField
                autoFocus multiline rows={4} fullWidth
                variant="outlined" label="Your Comment"
                value={comment} onChange={(e) => setComment(e.target.value)}
              />
            </DialogContent>
            <DialogActions>
              <Button onClick={handleCloseComments}>Cancel</Button>
              <Button variant="contained" onClick={handleSubmitComment}>Submit</Button>
            </DialogActions>
          </Dialog>

                    {subcategories.length > 0 && (
            <Box sx={{ mb: 2 }}>
              <Typography variant="subtitle1" fontWeight="bold" mb={1}>Subcategories:</Typography>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1 }}>
        {subcategories.map((sub) => (
          <Chip
            key={sub.id}
            label={sub.name}
            variant="outlined"
            color="primary"
            clickable
            onClick={() => navigate(`/subcategory/${sub.name}`)}
            sx={{
              fontWeight: 500,
              borderRadius: 2,
              px: 1.5,
              py: 0.5,
              fontSize: '0.85rem',
              '&:hover': {
                backgroundColor: 'primary.light',
              },
            }}
          />
        ))}
      </Box>
            </Box>
          )}
        </Box>
      </Box>
    </>
  );
};

export default Home;
