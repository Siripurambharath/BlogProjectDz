import React, { useEffect, useState } from 'react';
import {
  Box, Table, TableBody, TableCell, TableHead, TableRow,
  Typography, Paper, IconButton, Tooltip, TextField, Button
} from '@mui/material';
import Navbar2 from './Navbar2';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import SaveIcon from '@mui/icons-material/Save';
import AddIcon from '@mui/icons-material/Add';
import axios from 'axios';

const Categories = () => {
  const [categories, setCategories] = useState([]);
  const [editId, setEditId] = useState(null);
  const [editValue, setEditValue] = useState('');
  const [newCategory, setNewCategory] = useState('');

  const fetchCategories = async () => {
    const res = await axios.get('http://localhost:5000/categories');
    setCategories(res.data.reverse()); // Show newest first
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  const handleSave = async (id) => {
    try {
      await axios.put(`http://localhost:5000/categories/${id}`, { name: editValue });
      window.alert('Category updated successfully');
      setEditId(null);
      setEditValue('');
      fetchCategories();
    } catch (error) {
      console.error('Update failed:', error);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/categories/${id}`);
      window.alert('Category deleted successfully');
      fetchCategories();
    } catch (error) {
      console.error('Delete failed:', error);
    }
  };

  const handleEdit = (category) => {
    setEditId(category.id);
    setEditValue(category.name);
  };

const handleAdd = async () => {
  if (!newCategory.trim()) {
    window.alert("Text doesn't exist");
    return;
  }
  try {
    await axios.post('http://localhost:5000/categories', { name: newCategory });
    window.alert('Category added successfully'); // ✅ Alert on successful addition
    setNewCategory('');
    fetchCategories();
  } catch (error) {
    console.error('Add failed:', error);
  }
};


  return (
    <>
      <Navbar2 />
      <Box sx={{ p: 3, display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <Typography variant="h4" sx={{ alignSelf: 'flex-start', mb: 2 }}>Categories Table</Typography>

        {/* Add Category Input Above Table */}
        <Box sx={{ display: 'flex', gap: 2, mb: 2, width: '100%', maxWidth: 400 }}>
          <TextField
            fullWidth
            label="Enter a new category"
            value={newCategory}
            onChange={(e) => setNewCategory(e.target.value)}
          />
         
       <Button
  variant="contained"

  onClick={handleAdd}
  sx={{ backgroundColor:'#a5d6a7' }} 
  startIcon={<AddIcon />}
>
  Add
</Button>

     
        </Box>

        {/* Categories Table */}
        <Paper sx={{ width: '100%', maxWidth: 700, boxShadow: 3 }}>
          <Table>
            <TableHead>
              <TableRow sx={{ backgroundColor: '#a5d6a7' }}>
                <TableCell align="center" sx={{ color: '#fff', fontWeight: 'bold' }}>S.No</TableCell>
                <TableCell align="center" sx={{ color: '#fff', fontWeight: 'bold' }}>Name</TableCell>
                <TableCell align="center" sx={{ color: '#fff', fontWeight: 'bold' }}>Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {categories.map((cat, index) => (
                <TableRow key={cat.id}>
                  <TableCell align="center">{index + 1}</TableCell>
                  <TableCell align="center">
                    {editId === cat.id ? (
                      <input
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        style={{ width: 150, padding: '8px', fontSize: '16px' }}
                      />
                    ) : (
                      cat.name
                    )}
                  </TableCell>
                  <TableCell align="center">
                    {editId === cat.id ? (
                      <IconButton color="success" onClick={() => handleSave(cat.id)}>
                        <SaveIcon />
                      </IconButton>
                    ) : (
                      <IconButton color="primary" onClick={() => handleEdit(cat)}>
                        <EditIcon />
                      </IconButton>
                    )}
                    <IconButton color="error" onClick={() => handleDelete(cat.id)}>
                      <DeleteIcon />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Paper>
      </Box>
    </>
  );
};

export default Categories;
