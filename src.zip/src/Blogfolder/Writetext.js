import React, { useEffect, useState } from 'react';
import {
  Box,
  FormControl,
  InputLabel,
  MenuItem,
  Paper,
  TextField,
  Typography,
  Select,
  Button,
IconButton,
} from '@mui/material';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { Link } from 'react-router-dom';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

import Navbar2 from './Navbar2';

const Writetext = () => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [postContent, setPostContent] = useState('');
  const [imageFile, setImageFile] = useState(null);
  const [imageName, setImageName] = useState('');
  const [categories, setCategories] = useState([]); // dynamic category list

  // Fetch categories from backend
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const res = await fetch('http://localhost:5000/categories');
        const data = await res.json();
        setCategories(data); // assuming data is an array of category objects
      } catch (error) {
        console.error('Error fetching categories:', error);
      }
    };

    fetchCategories();
  }, []);

  const handleSubmit = async () => {
    if (!title.trim() || !category || !postContent.trim() || !imageFile) {
      alert('Please fill in all fields and select an image before submitting.');
      return;
    }

    const formData = new FormData();
    formData.append('title', title);
    formData.append('category', category);
    formData.append('content', postContent);
    formData.append('image', imageFile);

    try {
      const res = await fetch('http://localhost:5000/blog', {
        method: 'POST',
        body: formData,
      });

      if (res.ok) {
        alert('Blog submitted!');
        setTitle('');
        setCategory('');
        setPostContent('');
        setImageFile(null);
        setImageName('');
      } else {
        alert('Submission failed');
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <>
      <Navbar2 />
      <Box sx={{ mt: 2 }}>
                 <Box sx={{ display: 'flex', justifyContent: 'flex-start',alignItems:'center',paddingLeft:4 }}>
                      <Link to="/posts">
                        <IconButton color="primary"><ArrowBackIcon /></IconButton>
                      </Link>
                    </Box>
        <Paper
          sx={{
            width: 600,
            margin: 'auto',
            p: 2,
            borderRadius: 3,
            backgroundColor: '#f5f5f5',
          }}
        >
          <Typography variant="h4" align="center" fontWeight="bold">
            Create Blog
          </Typography>

          <TextField
            label="Title"
            fullWidth
            margin="normal"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />

          <FormControl fullWidth margin="normal">
            <InputLabel>Category</InputLabel>
            <Select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              label="Category"
            >
              {categories.map((cat, index) => (
                <MenuItem key={index} value={cat.name}>
                  {cat.name}
                </MenuItem>
              ))}
            </Select>
          </FormControl>

          <Button variant="outlined" component="label" fullWidth sx={{ mt: 2 }}>
            {imageName || 'Select Image'}
            <input
              type="file"
              hidden
              onChange={(e) => {
                const file = e.target.files[0];
                if (file) {
                  setImageFile(file);
                  setImageName(file.name);
                }
              }}
            />
          </Button>

          <Typography variant="subtitle1" sx={{ mt: 3, mb: 1 }}>
            Post Content
          </Typography>

          <ReactQuill
            value={postContent}
            onChange={setPostContent}
            style={{ height: '200px', marginBottom: '40px' }}
            placeholder="Write your post here..."
            modules={{
              toolbar: [
                [{ header: [1, 2, 3, false] }],
                ['bold', 'italic', 'underline'],
                [{ list: 'ordered' }, { list: 'bullet' }],
                ['clean'],
              ],
            }}
          />

          <Button variant="contained" sx={{ mt: 2 }} onClick={handleSubmit}>
            SUBMIT
          </Button>
        </Paper>
      </Box>
    </>
  );
};

export default Writetext;
